package com.example.musiclist;

public interface PlayNotification {
    void onTrackPrevious();
    void onTrackPlay();
    void onTrackPause();
    void onTrackNext();
}
